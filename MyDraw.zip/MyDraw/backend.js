let canvas = document.getElementById("canvas");
let upload_image = document.getElementById("up-img");
let draw_image = document.getElementById("te-img");
let clear = document.getElementById("clear");
let ctx = canvas.getContext("2d");
let bias = document.getElementById("bias");

let colors = [];
let color_X = [];
let color_Y = [];

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

clear.addEventListener('click', () => {
	ctx.clearRect(0,0,800,600);
});

upload_image.addEventListener('change', (event) => {
	const file = event.target.files[0];
	if (!file) return;
	
	const image = new Image();
	const imageURL = URL.createObjectURL(file);
	
	image.onload = () => {
		const width = 800;
		const height = 600;
		
		canvas.width = width;
		canvas.height = height;
		
		ctx.drawImage(image,0,0,width,height);
		
		const imageData = ctx.getImageData(0,0,width,height);
		const pixels = imageData.data;
		
		for (let y = 0; y < height; y++) {
			for (let x = 0; x < width; x++) {
				const index = (y * width + x) * 4;
				
				const red = pixels[index];
				const green = pixels[index + 1];
				const blue = pixels[index + 2];
				
				const hex = "#" + [red,green,blue]
					.map(value => value.toString(16).padStart(2,"0"))
					.join("");
				
				colors.push(hex);
				color_X.push(x);
				color_Y.push(y);
			}
		}
		
		console.log(colors[1] + ", " + colors[2] + ", " + colors[3] + "...");
		upload_image.value = "";
		URL.revokeObjectURL(imageURL);
	};
	
	image.src = imageURL;
});

function neuron_judgement(pixel_x, pixel_y, pixel_r, pixel_g, pixel_b) {
	const brightness = (pixel_r + pixel_g + pixel_b) / 255;

	const x = (pixel_x / (800 - 1)) * 2 - 1;
    const y = (pixel_y / (600 - 1)) * 2 - 1;

	const random_value = Math.random() - 0.5;

	let score
	
	if (bias.value == "random") {
		score = -(Math.random())
			+ Math.random() * x
			+ Math.random() * y
			+ Math.random() * brightness
			+ Math.random() * random_value
			+ Math.random() * (pixel_r / 255)
			+ Math.random() * (pixel_g / 255)
			+ Math.random() * (pixel_b / 255);
	} else if (bias.value == "balanced") {
		score = -1.0
			+ 0.3 * x
			+ 0.3 * y
			+ 0.5 * brightness
			+ 0.8 * random_value
			+ 0.8 * (pixel_r / 255)
			+ 0.8 * (pixel_g / 255)
			+ 0.8 * (pixel_b / 255);
	} else if (bias.value == "dark") {
		score = -0.5
			+ 0.2 * x
			+ 0.2 * y
			+ -1.0 * brightness
			+ 0.8 * random_value
			+ -1.0 * (pixel_r / 255)
			+ -1.0 * (pixel_g / 255)
			+ -1.0 * (pixel_b / 255);
	} else if (bias.value == "waves") {
	 	const r = pixel_r / 255;
	 	const g = pixel_g / 255;
	 	const b = pixel_b / 255;
	 	
	 	const brightness = (r + g + b) / 3;
	 	const distance = Math.sqrt(x * x + y * y);
	 	const rings = Math.sin(distance * 18.0);
	 	const waves = Math.sin(x * 13.0 + y * 9.0) + Math.cos(x * 8.0 - y * 15.0);
	 	const edge = distance;
	 	const chaos = random_value;
	 	
	 	score = -0.8
        	- 2.2 * brightness
        	+ 0.8 * rings
        	+ 0.45 * waves
        	+ 0.5 * edge
        	+ 1.2 * chaos;
	} else if (bias.value === "vhs") {
    	const r = pixel_r / 255;
    	const g = pixel_g / 255;
    	const b = pixel_b / 255;

	    const scanline = Math.sin(pixel_y * 0.35);

	    const streak =
	        Math.sin(pixel_y * 0.08 + pixel_x * 0.015) +
	        Math.sin(pixel_y * 0.19) * 0.5;

	    const glitch = (Math.random() - 0.5) * 2;

	    score =
	        -1.0
	        + 0.3 * x
	        + 0.3 * y
	        + 0.5 * brightness
	        - 0.8 * random_value
	        + 1.0 * r
	        + 1.0 * g
	        + 1.0 * b
	        + 1.2 * streak
	        - 0.4 * scanline
	        + 0.8 * glitch;
	}
	
	const probability = 1 / (1 + Math.exp(-score));
	return Math.random() < probability;
}

function hexToRgb(hex) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return {
    	r: parseInt(hex.slice(1, 3), 16),
    	g: parseInt(hex.slice(3, 5), 16),
    	b: parseInt(hex.slice(5, 7), 16)
    };
};


draw_image.addEventListener('click', () => {
	for (let i = 0; i < 5; i++) {
		for (let x = 0; x < 800; x++) {
			for (let y = 0; y < 600; y++) {
				let random_element = getRandomInt(0,colors.length - 1);
				let pixelx = color_X[random_element];
				let pixely = color_Y[random_element];
			
				let pixelr = hexToRgb(colors[random_element]).r;
				let pixelg = hexToRgb(colors[random_element]).g;
				let pixelb = hexToRgb(colors[random_element]).b;
			
				if (neuron_judgement(pixelx, pixely, pixelr, pixelg, pixelb)) {
					ctx.fillStyle = colors[random_element];
					ctx.fillRect(pixelx, pixely, 1, 1);
				}
			}
		}
	}
});